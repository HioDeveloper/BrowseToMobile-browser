package androidx.transition;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Xml;
import android.view.InflateException;
import android.view.ViewGroup;
import androidx.collection.ArrayMap;
import androidx.core.content.res.TypedArrayUtils;
import java.io.IOException;
import java.lang.reflect.Constructor;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: classes.dex */
public class TransitionInflater {
    private final Context mContext;
    private static final Class<?>[] CONSTRUCTOR_SIGNATURE = {Context.class, AttributeSet.class};
    private static final ArrayMap<String, Constructor<?>> CONSTRUCTORS = new ArrayMap<>();

    private TransitionInflater(Context context) {
        this.mContext = context;
    }

    public static TransitionInflater from(Context context) {
        return new TransitionInflater(context);
    }

    public Transition inflateTransition(int resource) {
        XmlResourceParser parser = this.mContext.getResources().getXml(resource);
        try {
            try {
                Transition transitionCreateTransitionFromXml = createTransitionFromXml(parser, Xml.asAttributeSet(parser), null);
                parser.close();
                return transitionCreateTransitionFromXml;
            } catch (IOException e) {
                throw new InflateException(parser.getPositionDescription() + ": " + e.getMessage(), e);
            } catch (XmlPullParserException e2) {
                throw new InflateException(e2.getMessage(), e2);
            }
        } catch (Throwable th) {
            parser.close();
            throw th;
        }
    }

    public TransitionManager inflateTransitionManager(int resource, ViewGroup sceneRoot) {
        XmlResourceParser parser = this.mContext.getResources().getXml(resource);
        try {
            try {
                TransitionManager transitionManagerCreateTransitionManagerFromXml = createTransitionManagerFromXml(parser, Xml.asAttributeSet(parser), sceneRoot);
                parser.close();
                return transitionManagerCreateTransitionManagerFromXml;
            } catch (IOException e) {
                InflateException ex = new InflateException(parser.getPositionDescription() + ": " + e.getMessage());
                ex.initCause(e);
                throw ex;
            } catch (XmlPullParserException e2) {
                InflateException ex2 = new InflateException(e2.getMessage());
                ex2.initCause(e2);
                throw ex2;
            }
        } catch (Throwable th) {
            parser.close();
            throw th;
        }
    }

    private Transition createTransitionFromXml(XmlPullParser parser, AttributeSet attrs, Transition parent) throws XmlPullParserException, IOException {
        Transition transition = null;
        int depth = parser.getDepth();
        TransitionSet transitionSet = parent instanceof TransitionSet ? (TransitionSet) parent : null;
        while (true) {
            int type = parser.next();
            if ((type == 3 && parser.getDepth() <= depth) || type == 1) {
                break;
            }
            if (type == 2) {
                String name = parser.getName();
                if ("fade".equals(name)) {
                    transition = new Fade(this.mContext, attrs);
                } else if ("changeBounds".equals(name)) {
                    transition = new ChangeBounds(this.mContext, attrs);
                } else if ("slide".equals(name)) {
                    transition = new Slide(this.mContext, attrs);
                } else if ("explode".equals(name)) {
                    transition = new Explode(this.mContext, attrs);
                } else if ("changeImageTransform".equals(name)) {
                    transition = new ChangeImageTransform(this.mContext, attrs);
                } else if ("changeTransform".equals(name)) {
                    transition = new ChangeTransform(this.mContext, attrs);
                } else if ("changeClipBounds".equals(name)) {
                    transition = new ChangeClipBounds(this.mContext, attrs);
                } else if ("autoTransition".equals(name)) {
                    transition = new AutoTransition(this.mContext, attrs);
                } else if ("changeScroll".equals(name)) {
                    transition = new ChangeScroll(this.mContext, attrs);
                } else if ("transitionSet".equals(name)) {
                    transition = new TransitionSet(this.mContext, attrs);
                } else if ("transition".equals(name)) {
                    transition = (Transition) createCustom(attrs, Transition.class, "transition");
                } else if ("targets".equals(name)) {
                    getTargetIds(parser, attrs, parent);
                } else if ("arcMotion".equals(name)) {
                    if (parent == null) {
                        throw new RuntimeException("Invalid use of arcMotion element");
                    }
                    parent.setPathMotion(new ArcMotion(this.mContext, attrs));
                } else if ("pathMotion".equals(name)) {
                    if (parent != null) {
                        parent.setPathMotion((PathMotion) createCustom(attrs, PathMotion.class, "pathMotion"));
                    } else {
                        throw new RuntimeException("Invalid use of pathMotion element");
                    }
                } else if ("patternPathMotion".equals(name)) {
                    if (parent == null) {
                        throw new RuntimeException("Invalid use of patternPathMotion element");
                    }
                    parent.setPathMotion(new PatternPathMotion(this.mContext, attrs));
                } else {
                    throw new RuntimeException("Unknown scene name: " + parser.getName());
                }
                if (transition == null) {
                    continue;
                } else {
                    if (!parser.isEmptyElementTag()) {
                        createTransitionFromXml(parser, attrs, transition);
                    }
                    if (transitionSet != null) {
                        transitionSet.addTransition(transition);
                        transition = null;
                    } else if (parent != null) {
                        throw new InflateException("Could not add transition to another transition.");
                    }
                }
            }
        }
        return transition;
    }

    private Object createCustom(AttributeSet attrs, Class<?> expectedType, String tag) {
        Object objNewInstance;
        Class<?> c;
        String className = attrs.getAttributeValue(null, "class");
        if (className == null) {
            throw new InflateException(tag + " tag must have a 'class' attribute");
        }
        try {
            synchronized (CONSTRUCTORS) {
                Constructor<?> constructor = CONSTRUCTORS.get(className);
                if (constructor == null && (c = Class.forName(className, false, this.mContext.getClassLoader()).asSubclass(expectedType)) != null) {
                    constructor = c.getConstructor(CONSTRUCTOR_SIGNATURE);
                    constructor.setAccessible(true);
                    CONSTRUCTORS.put(className, constructor);
                }
                objNewInstance = constructor.newInstance(this.mContext, attrs);
            }
            return objNewInstance;
        } catch (Exception e) {
            throw new InflateException("Could not instantiate " + expectedType + " class " + className, e);
        }
    }

    private void getTargetIds(XmlPullParser parser, AttributeSet attrs, Transition transition) throws XmlPullParserException, IOException {
        int depth = parser.getDepth();
        while (true) {
            int type = parser.next();
            if ((type != 3 || parser.getDepth() > depth) && type != 1) {
                if (type == 2) {
                    String name = parser.getName();
                    if (name.equals("target")) {
                        TypedArray a = this.mContext.obtainStyledAttributes(attrs, Styleable.TRANSITION_TARGET);
                        int id = TypedArrayUtils.getNamedResourceId(a, parser, "targetId", 1, 0);
                        if (id == 0) {
                            int id2 = TypedArrayUtils.getNamedResourceId(a, parser, "excludeId", 2, 0);
                            if (id2 != 0) {
                                transition.excludeTarget(id2, true);
                            } else {
                                String transitionName = TypedArrayUtils.getNamedString(a, parser, "targetName", 4);
                                if (transitionName != null) {
                                    transition.addTarget(transitionName);
                                } else {
                                    String transitionName2 = TypedArrayUtils.getNamedString(a, parser, "excludeName", 5);
                                    if (transitionName2 != null) {
                                        transition.excludeTarget(transitionName2, true);
                                    } else {
                                        String className = TypedArrayUtils.getNamedString(a, parser, "excludeClass", 3);
                                        if (className == null) {
                                            String className2 = TypedArrayUtils.getNamedString(a, parser, "targetClass", 0);
                                            if (className2 != null) {
                                                Class<?> clazz = Class.forName(className2);
                                                transition.addTarget(clazz);
                                            }
                                        } else {
                                            try {
                                                Class<?> clazz2 = Class.forName(className);
                                                transition.excludeTarget(clazz2, true);
                                            } catch (ClassNotFoundException e) {
                                                a.recycle();
                                                throw new RuntimeException("Could not create " + className, e);
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            transition.addTarget(id);
                        }
                        a.recycle();
                    } else {
                        throw new RuntimeException("Unknown scene name: " + parser.getName());
                    }
                }
            } else {
                return;
            }
        }
    }

    private TransitionManager createTransitionManagerFromXml(XmlPullParser parser, AttributeSet attrs, ViewGroup sceneRoot) throws XmlPullParserException, IOException {
        int depth = parser.getDepth();
        TransitionManager transitionManager = null;
        while (true) {
            int type = parser.next();
            if ((type == 3 && parser.getDepth() <= depth) || type == 1) {
                break;
            }
            if (type == 2) {
                String name = parser.getName();
                if (name.equals("transitionManager")) {
                    transitionManager = new TransitionManager();
                } else if (name.equals("transition") && transitionManager != null) {
                    loadTransition(attrs, parser, sceneRoot, transitionManager);
                } else {
                    throw new RuntimeException("Unknown scene name: " + parser.getName());
                }
            }
        }
        return transitionManager;
    }

    private void loadTransition(AttributeSet attrs, XmlPullParser parser, ViewGroup sceneRoot, TransitionManager transitionManager) throws Resources.NotFoundException {
        Transition transition;
        TypedArray a = this.mContext.obtainStyledAttributes(attrs, Styleable.TRANSITION_MANAGER);
        int transitionId = TypedArrayUtils.getNamedResourceId(a, parser, "transition", 2, -1);
        int fromId = TypedArrayUtils.getNamedResourceId(a, parser, "fromScene", 0, -1);
        Scene fromScene = fromId < 0 ? null : Scene.getSceneForLayout(sceneRoot, fromId, this.mContext);
        int toId = TypedArrayUtils.getNamedResourceId(a, parser, "toScene", 1, -1);
        Scene toScene = toId >= 0 ? Scene.getSceneForLayout(sceneRoot, toId, this.mContext) : null;
        if (transitionId >= 0 && (transition = inflateTransition(transitionId)) != null) {
            if (toScene == null) {
                throw new RuntimeException("No toScene for transition ID " + transitionId);
            }
            if (fromScene == null) {
                transitionManager.setTransition(toScene, transition);
            } else {
                transitionManager.setTransition(fromScene, toScene, transition);
            }
        }
        a.recycle();
    }
}
